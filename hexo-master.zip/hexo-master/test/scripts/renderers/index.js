'use strict';

describe('Renderers', () => {
  require('./json');
  require('./plain');
  require('./swig');
  require('./yaml');
});
