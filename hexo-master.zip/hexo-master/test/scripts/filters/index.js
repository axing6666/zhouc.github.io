'use strict';

describe('Filters', () => {
  require('./backtick_code_block');
  require('./excerpt');
  require('./external_link');
  require('./i18n_locals');
  require('./new_post_path');
  require('./post_permalink');
  require('./render_post');
  require('./save_database');
  require('./titlecase');
});
