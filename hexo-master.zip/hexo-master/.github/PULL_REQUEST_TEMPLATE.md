Thank you for creating a pull request to contribute to Hexo code! Before you open the request please review the following guidelines and tips to help it be more easily integrated:

- [ ] Add test cases for the changes.
- [ ] Passed the CI test.
